#include "kernel/system.h"
#include <minix/endpoint.h>

#if USE_MSGCOUNTER

static int msg_counts = 0;

int do_msgcounter(struct proc * caller, message * m_ptr)
{
    msg_counts = msg_counts + 1;
    printf("/usr/src/minix/kernel/system/do_msgcounter\n");
    m_ptr->m_pm_lsys_msgcounter.counts = msg_counts;
    print("Number of messages %d", msg_counts);
    return OK;
}