#include "pm.h"
#include <minix/callnr.h>
#include <minix/com.h>
#include <minix/syslib.h>
#include "glo.h"
#include "mproc.h"

int do_inittrapcounter()
{
 printf("usr/src/minix/servers/pm/inittrapcounter.c \n");
 register struct mproc *sending_proc = mp;
 int inc = 0;
 int r = sys_inittrapcounter(sending_proc->mp_endpoint, &inc);
 if(r != OK){
 printf("Error in kernel inside inittrapcounter.c [%d]\n", r);
 return r;
}
 printf("Success from inittrapcounter.c %d", inc);
 return inc;
}

