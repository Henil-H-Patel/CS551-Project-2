#include<sys/cdefs.h>
#include"namespace.h"
#include<lib.h>
#include<string.h>
#include<signal.h>

#ifdef __weak_alias
__weak_alias(kill, _kill)
#endif

int initmsgcounter()
{
message m;
printf("innitmsgcounter m %d\n",m);
memset(&m, 0, sizeof(m));
printf("/usr/src/minix/lib/libc/sys/initmsgcounter.c");
return (_syscall(PM_PROC_NR, PM_INITMSGCOUNTER, &m));
}
