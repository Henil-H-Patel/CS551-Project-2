#include<sys/cdefs.h>
#include"namespace.h"
#include<lib.h>
#include<string.h>
#include<signal.h>

#ifdef __weak_alias
__weak_alias(kill, _kill)
#endif

int inittrapcounter()
{
message m;
printf("innittrapcounter m %d\n",m);
memset(&m, 0, sizeof(m));
printf("/usr/src/minix/lib/libc/sys/inittrapcounter.c");
return (_syscall(PM_PROC_NR, PM_INITTRAPCOUNTER, &m));
}
