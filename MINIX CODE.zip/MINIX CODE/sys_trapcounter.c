#include "syslib.h"

int sys_trapcounter(endpoint_t proc_ep, int *trapcounter_count)
{
	message m;
	int ret = _kernel_call(SYS_TRAPCOUNTER, &m);
	if (ret != OK)
{
	printf("libsys error in kernel call %d\n", ret);
	return ret;
}
	*trapcounter_count = m.m_pm_lsys_trapcounter.num;
	printf(" /usr/src/minix/lib/libsys/sys_trapcounter %d", 
	m.m_pm_lsys_trapcounter.num);
	return(OK);
	
}

	
