#include "pm.h"
#include <minix/callnr.h>
#include <minix/com.h>
#include <minix/syslib.h>
#include "glo.h"
#include "mproc.h"

int do_initmsgcounter()
{
 printf("usr/src/minix/servers/pm/initmsgcounter.c \n");
 register struct mproc *sending_proc = mp;
 int inc = 0;
 int r = sys_initmsgcounter(sending_proc->mp_endpoint, &inc);
 if(r != OK){
 printf("Error in kernel inside initmsgcounter.c [%d]\n", r);
 return r;
}
 printf("Success from initmsgcounter.c %d", inc);
 return inc;
}