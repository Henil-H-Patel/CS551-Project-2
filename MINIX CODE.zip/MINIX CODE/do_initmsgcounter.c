#include "kernel/system.h"
#include <minix/endpoint.h>

#if USE_INITMSGTRAPCOUNTER

static int times_called = 0;

int do_initmsgtrapcounter(struct proc *caller, message *m_ptr)
{
    printf("/usr/src/minix/kernel/system/do_initmsgtrapcounter.c \n");
    m_ptr->m_pm_lsys_msgcounter.num = times_called;
    printf("minix/system/Kernel do_initmsgtrapcounter %d", times_called); 
    return OK;
}

#endif