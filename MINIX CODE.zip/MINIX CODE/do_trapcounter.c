#include "kernel/system.h"
#include <minix/endpoint.h>

#if USE_TRAPCOUNTER

static int times_called = 0;

int do_trapcounter(struct proc *caller, message *m_ptr) {
    times_called = times_called+1;
    printf("/usr/src/minix/kernel/system/do_trapcounter.c \n");
    m_ptr->m_pm_lsys_trapcounter.num = times_called;
    printf("minix/system/Kernel do_trapcounter %d", times_called);
    return OK;
}

#endif   /*USE_TRAPCOUNTER */
