#include "syslib.h"

int sys_msgcounter(endpoint_t proc_ep, int *msgcounter_count)
{
	message m;
	int ret = _kernel_call(SYS_MSGCOUNTER, &m);
	if (ret != OK)
{
	printf("libsys error in kernel call %d\n", ret);
	return ret;
}
	*msgcounter_count = m.m_pm_lsys_msgcounter.num;
	printf(" /usr/src/minix/lib/libsys/sys_msgcounter %d", 
m.m_pm_lsys_msgcounter.num);
	return(OK);
	
}

	
