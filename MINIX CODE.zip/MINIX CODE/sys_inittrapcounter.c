#include "syslib.h"

int sys_inittrapcounter(endpoint_t proc_ep, int *trapcounter_count)
{
	message m;
	int r = _kernel_call(SYS_INITTRAPCOUNTER, &m);
	printf("VAlue of r %d\n", r);
	*trapcounter_count = m.m_pm_lsys_trapcounter.num;
	printf(" /usr/src/minix/lib/libsys/sys_trapcounter %d", 
	m.m_pm_lsys_trapcounter.num);
	return OK;
}
