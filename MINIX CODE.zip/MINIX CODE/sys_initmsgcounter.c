#include "syslib.h"

int sys_initmsgcounter(endpoint_t proc_ep, int *initmsgcounter_count)
{
    message m;
    int r = _kernel_call(SYS_INITMSGCOUNTER, &m);
    printf("VAlue of r %d\n", r);
    *trapcounter_count = m.m_pm_lsys_msgcounter.num;
    printf(" /usr/src/minix/lib/libsys/sys_initmsgcounter %d", 
    m.m_pm_lsys_trapcounter.num);
    return OK;
}