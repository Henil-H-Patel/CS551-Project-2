#include "pm.h"
#include <minix/callnr.h>
#include <minix/com.h>
#include <minix/syslib.h>
#include "glo.h"
#include "mproc.h"

int do_trapcounter()
{
 printf("usr/src/minix/servers/pm/trapcounter.c \n");
 register struct mproc *sending_proc = mp;
 int inc = 0;
 int r = sys_trapcounter(sending_proc->mp_endpoint, &inc);
 if(r != OK){
 printf("Error in kernel inside trapcounter.c [%d]\n", r);
 return r;
}
 printf("Success from trapcounter.c %d", inc);
 return inc;
}

