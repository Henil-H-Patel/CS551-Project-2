#include "pm.h"
#include <minix/callnr.h>
#include <minix/com.h>
#include "mproc.h"

int do_msgcounter()
{
register struct mproc *sending_proc = mp;
int num_times = 0;
int ret = sys_msgcounter(sending_proc->mp_endpoint, &num_times);
if(ret != OK)
{
printf("Error : /usr/src/minix/servers/pm/msgcounter.c\n ");
printf("ret value %d", ret);
return ret;
}
return num_times;

}
