#include<sys/cdefs.h>
#include"namespace.h"
#include<lib.h>
#include<string.h>
#include<signal.h>

#ifdef __weak_alias
__weak_alias(kill, _kill)
#endif

int trapcounter()
{
message m;
printf("/usr/src/minix/lib/libc/sys/trapcounter.c");
memset(&m, 0, sizeof(m));
return (_syscall(PM_PROC_NR, PM_TRAPCOUNTER, &m));
}
